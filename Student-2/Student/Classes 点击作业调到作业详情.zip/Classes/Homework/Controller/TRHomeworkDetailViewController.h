#import <UIKit/UIKit.h>
#import "TRITObject.h"
@interface TRHomeworkDetailViewController : UIViewController
@property (nonatomic, strong)TRITObject *itObj;
@property (nonatomic)BOOL isFinished;
@end