//
//  SettingsViewController.h
//  Student
//
//  Created by tarena on 16/9/18.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TRSettingsViewController : UIViewController

@end
