//
//  NSString+TRPassword.h
//  Student
//
//  Created by tarena on 16/9/18.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (TRPassword)
- (BOOL)checkPassword;
@end
