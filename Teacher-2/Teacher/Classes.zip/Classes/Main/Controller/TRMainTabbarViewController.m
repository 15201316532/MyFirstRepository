//
//  TRMainTabbarViewController.m
//  Theater
//
//  Created by tarena on 16/9/13.
//  Copyright © 2016年 tarena. All rights reserved.
//
#import "TRMainNavigationController.h"
#import "TRMainTabbarViewController.h"
#import "TRHomeViewController.h"
#import "TRStoreTableViewController.h"
#import "TRStudentsTableViewController.h"
#import "TRSettingsTableViewController.h"

@interface TRMainTabbarViewController ()

@end

@implementation TRMainTabbarViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    TRHomeViewController *homeVC = [TRHomeViewController new];
    TRStudentsTableViewController *studentVC = [TRStudentsTableViewController new];
    TRStoreTableViewController *storeVC = [TRStoreTableViewController new];
    
    TRSettingsTableViewController *setttingsVC = [TRSettingsTableViewController new];
    
    homeVC.title = @"作业";
    studentVC.title = @"学生";
    storeVC.title = @"商品";
    setttingsVC.title = @"设置";
    
    
    
    
    homeVC.tabBarItem.image = [UIImage imageNamed:@"推荐_默认"];
    homeVC.tabBarItem.selectedImage = [UIImage imageNamed:@"推荐_焦点"];
    
    studentVC.tabBarItem.image = [UIImage imageNamed:@"我的_默认"];
    studentVC.tabBarItem.selectedImage = [UIImage imageNamed:@"我的_焦点"];
    
    storeVC.tabBarItem.image = [UIImage imageNamed:@"栏目_默认"];
    storeVC.tabBarItem.selectedImage = [UIImage imageNamed:@"栏目_焦点"];
    
    setttingsVC.tabBarItem.image = [UIImage imageNamed:@"系统设置"];
    setttingsVC.tabBarItem.selectedImage = [UIImage imageNamed:@"系统设置"];
    
    self.viewControllers = @[[[TRMainNavigationController alloc] initWithRootViewController:homeVC],[[TRMainNavigationController alloc] initWithRootViewController:studentVC],[[TRMainNavigationController alloc] initWithRootViewController:storeVC],[[TRMainNavigationController alloc] initWithRootViewController:setttingsVC]];
    
    
    self.tabBar.tintColor = MainColor;
}



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
