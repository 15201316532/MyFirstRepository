//
//  TRStoreDetialViewController.h
//  Teacher
//
//  Created by tarena on 16/9/14.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TRStoreDetialViewController : UIViewController
@property (nonatomic, strong)BmobObject *obj;
@end
