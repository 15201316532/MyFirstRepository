//
//  TRDetailViewController.h
//  ITSNS
//
//  Created by tarena on 16/8/29.
//  Copyright © 2016年 Ivan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TRITObject.h"
@interface TRDetailViewController : UIViewController
@property (nonatomic, strong)TRITObject *itObj;
@end
